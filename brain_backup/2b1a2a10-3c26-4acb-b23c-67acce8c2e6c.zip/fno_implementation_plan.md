# F&O OI-Confirmed Pre-Open Table — Implementation Plan

## Goal
Replace the "Top 5 Low-Opening Potential Stocks" table with a new **"Top 10 F&O Stocks — OI Confirmed"** table that:
1. Filters ONLY F&O-eligible stocks (~200 stocks)
2. Applies ALL existing pre-open business rules (Gap, IEQ, EQ_IMB, MO_IMB, EV, ALIGN)
3. Adds a NEW **OI Confirmation Layer** that uses overnight F&O data to validate/boost conviction
4. Ranks them with a combined score for maximum win probability

> [!IMPORTANT]
> The existing Custom Watchlist and Top 10 High-Opening tables remain **100% untouched**.

---

## The F&O OI Confirmation Scoring Model

### Data Sources
| Source | Endpoint | When to Fetch |
|:---|:---|:---|
| F&O Stock List | `fo_mktlots.csv` from NSE Archives | Once daily at startup |
| Stock Futures OI | `/api/liveEquity-derivatives?index=stock_fut` | At ~8:58 AM (before pre-open) |
| Option Chain (per stock) | `/api/option-chain-equities?symbol=X` | At ~8:58 AM for top candidates |

### The 3-Layer OI Confirmation Signals

#### Signal 1: Futures OI Buildup Direction
From the stock futures data, we get `openInterest` and `pChange` (price change %).

| Price Direction | OI Direction | Interpretation | Score |
|:---|:---|:---|:---|
| Price UP + OI UP | Long Buildup | Smart money is ADDING fresh longs | **+1.0** |
| Price UP + OI DOWN | Short Covering | Shorts panicking — weak rally | **+0.3** |
| Price DOWN + OI UP | Short Buildup | Smart money is ADDING fresh shorts | **-1.0** (for LONG) |
| Price DOWN + OI DOWN | Long Unwinding | Longs giving up | **-0.3** (for LONG) |

#### Signal 2: Put-Call Ratio (PCR) at Nearby Strikes
From the option chain around the IEP:
- **PCR > 1.2** → Heavy Put writing = Strong SUPPORT below = Bullish = **+0.5**
- **PCR 0.8–1.2** → Neutral = **0.0**
- **PCR < 0.8** → Heavy Call writing = Strong RESISTANCE above = Bearish = **-0.5**

#### Signal 3: Max Pain & Trapped Writers
- If IEP is **above** the Max Call OI strike → Call writers are trapped → Forced buying = **+0.5**
- If IEP is **below** the Max Put OI strike → Put writers are trapped → Forced selling = **-0.5**

### Combined F&O Score Formula
```
fno_oi_score = (
    BUILDUP_SIGNAL      (range: -1.0 to +1.0)
  + PCR_SIGNAL          (range: -0.5 to +0.5)
  + TRAPPED_WRITER      (range: -0.5 to +0.5)
)
# Normalized to 0–1 range: (fno_oi_score + 2.0) / 4.0
```

### Final Combined F&O Table Score
```
FNO_FINAL_SCORE = (
    0.65 × EXISTING_PRE_OPEN_SCORE (Gap + IEQ + EQ_IMB + MO_IMB + EV + ALIGN)
  + 0.35 × FNO_OI_SCORE_NORMALIZED × 100
)
```

> [!TIP]
> The 65/35 split ensures pre-open order flow remains the primary signal, with F&O OI acting as a powerful secondary confirmation that boosts or penalizes conviction.

---

## Implementation Steps

### Step 1: Create `preopen_analyzer/fno_client.py`
- Download F&O stock list from `fo_mktlots.csv`
- Fetch stock futures data from `/api/liveEquity-derivatives?index=stock_fut`
- Fetch option chain for individual stocks
- Cache results in memory

### Step 2: Create `preopen_analyzer/fno_scoring.py`
- `calculate_fno_signals(symbol, iep, prev_close, futures_data, option_chain_data)`
- Returns: `buildup_type`, `pcr`, `max_pain_signal`, `fno_oi_score`

### Step 3: Update `preopen_analyzer/report.py`
- Add `_write_fno_csv()` to generate `fno_top10_{date}.csv`
- Include columns: SYMBOL, FINAL_SCORE, PRE_OPEN_SCORE, FNO_OI_SCORE, BUILDUP, PCR, IEP, GAP_PCT, ALIGN

### Step 4: Update `preopen_analyzer/main.py`
- In `_produce_final_decision()`, after LONG scoring, filter F&O-only stocks
- Fetch F&O OI data for those stocks
- Calculate combined score
- Store in `decision.top_10_fno`

### Step 5: Update `dashboard.py`
- Replace the Short table block with the new F&O table
- Add color coding for BUILDUP column (green=LONG_BUILDUP, red=SHORT_BUILDUP)
- Add PCR color coding

### Step 6: Update `models.py`
- Add `top_10_fno` field to `FinalDecision`
- Add F&O fields to `StockCandidate`: `fno_buildup`, `fno_pcr`, `fno_oi_score`
