# NSE Pre-Open Strategy: Deterministic Mathematical Model

This document outlines the current production business logic for the Pre-Open Market Analyzer, following the strict deterministic rewrite implemented on Sept 29, 2026. The AI-driven heuristic penalties (Stretch Risk, Reversal Risk, and Spread limits) have been entirely removed in favor of a pure mathematical percentile-ranking model.

---

## 1. Data Collection & Universe
* **Schedule:** The engine runs on a loop from `09:00:00` to `09:12:00` every 30 seconds.
* **Universe:** It scans the absolute entirety of the NSE Cash Market (~2000 stocks). No predefined watchlists (other than user-specific tracking), no F&O limitations, and no index limitations are applied to the core ranking.
* **Snapshot Lock:** The final definitive ranking is locked exactly at `09:12 AM` when the exchange halts order matching.

---

## 2. Hard Eligibility Filters
Before a stock is permitted into the cross-sectional ranking engine, it must survive the following gates:

### High-Opening Potential (LONG Engine)
1. **Valid Data:** Must have a valid Previous Close and Indicative Equilibrium Price (IEP).
2. **Positive Gap:** The stock MUST be gapping up (`IEP > Previous Close`).
3. **Liquidity Floor:** The Indicative Executable Value (IEP × IEQ) must be **≥ ₹0.05 Crores (₹5 Lakhs)**.

### Low-Opening Potential (SHORT Engine)
1. **Valid Data:** Must have a valid Previous Close and Indicative Equilibrium Price (IEP).
2. **Negative Gap:** The stock MUST be gapping down (`IEP < Previous Close`).
3. **Liquidity Floor:** The Indicative Executable Value (IEP × IEQ) must be **≥ ₹0.05 Crores (₹5 Lakhs)**.

*Note: The previous ₹1.0 Crore hard limit and 1,000 IEQ share limit have been permanently removed to surface highly explosive, lower-float setups.*

---

## 3. The 6-Factor Cross-Sectional Engine
All surviving stocks are thrown into a pool and mathematically ranked against each other across the following 6 factors. 

**(1) Gap Score (Linear)**
* Formula: `min(abs(Gap %), 10.0) / 10.0`
* Meaning: Gaps are rewarded linearly up to 10%. Anything above 10% receives the maximum cap (1.0). The previous "Stretch Risk" penalty for gaps > 8% no longer exists.

**(2) Equilibrium Imbalance Percentile**
* Formula: `rank(RAW EQ Imbalance)` 
* Meaning: We no longer calculate an imbalance ratio. The raw number of unbalanced shares left over at the matching price is ranked cross-sectionally. Negative values are kept as-is and naturally sink to the bottom.

**(3) Market Order Imbalance Percentile**
* Formula: `rank(max(RAW MO Imbalance, 0))`
* Meaning: Measures pure blind aggression. For LONGs, negative market imbalances are zeroed out so they don't skew the percentile negatively, ensuring we only reward positive aggression.

**(4) IEQ Percentile**
* Formula: `rank(RAW IEQ)`
* Meaning: Simply measures total traded share volume at the auction price compared to the rest of the market. 

**(5) Executable Value Percentile**
* Formula: `rank(Executable Value in Crores)`
* Meaning: Rewards stocks where actual heavy Rupee turnover is occurring, preventing highly imbalanced but cheap micro-caps from dominating.

**(6) Order-Flow Alignment**
* Formula: `1.0` if BOTH Equilibrium Imbalance AND Market Order Imbalance are in the direction of the trade (Positive for Longs, Negative for Shorts). Otherwise `0.0`.
* Meaning: A massive structural bonus is awarded when limit orders and market orders agree with the direction of the gap.

---

## 4. Final Scoring & Weights
The final `FINAL_SCORE` is calculated out of a perfect 100 points, using ultra-precise, statistically derived floating-point weights:

| Metric | Weight | Description |
| :--- | :--- | :--- |
| **EQ Imbalance** | `38.665` | The heaviest weight. Pure outstanding demand/supply at the matching price. |
| **Alignment** | `18.734` | The second heaviest weight. A pure binary bonus for perfect directional flow. |
| **Gap Quality** | `15.659` | Linear score rewarding the sheer size of the move up to 10%. |
| **MO Imbalance** | `13.822` | Rewards blind market-order aggression. |
| **Exec. Value** | `10.417` | Capital commitment ranking. |
| **IEQ** | `2.703` | Raw share count ranking. |

---

## 5. Output & Tie-Breakers
The system deterministically sorts the universe by `FINAL_SCORE`. If two stocks share the exact same score, the system breaks the tie using the following strict hierarchy:
1. Executable Value
2. IEQ
3. EQ Imbalance
4. MO Imbalance
5. Gap %

The top 10 results are pushed to the Streamlit UI, alongside a dedicated processing loop that ranks the user's `CUSTOM_WATCHLIST` using the exact same metrics, generating both a `BUY_SCORE` and `SELL_SCORE` side-by-side.
