# Transition to High-Opening Potential Engine (ALL Stocks)

The user has requested a complete overhaul of the current 50-parameter momentum engine to match a strict deterministic requirement document for a **High-Opening Potential Engine**. 

## Goal
Transform the system to evaluate the *entire* NSE market (all 2000+ stocks) and produce an "Opening Strength Score" (0-100) based on cross-sectional percentile ranking of executable value, order-book imbalance, and non-linear gap scoring.

## User Review Required
> [!WARNING]
> This represents a massive shift in logic. 
> 1. **Shorts Removed:** The new requirements explicitly state to reject any stock with `IEP <= PREV_CLOSE`. The SHORT tracking system we built yesterday will be removed.
> 2. **Entry/Exit Targets Removed:** The requirements state "Do not mix post-9:15 behavior into the 9:07 ranking". The limit entry, target, stop loss, and position sizing logic will be removed from the Top 10 Output.
> 3. **Universe Expansion:** We will track ~2000 stocks instead of 200. This will take slightly more CPU but is well within limits.
> Please click **Proceed** if you agree to drop the Shorts and Entry/Exit targets to match these new strict ranking rules.

## Proposed Changes

### Core Models & Config (`models.py`, `config.py`)
#### [MODIFY] `preopen_analyzer/models.py`
- Strip out `SHORT` enum types.
- Add new enum values for `OrderFlowAlignment` (`STRONG`, `MIXED`, `CONTRADICTORY`).
- Add new enum values for `StretchRisk` (`LOW`, `MODERATE`, `HIGH`, `VERY_HIGH`, `EXTREME`).
- Add new float fields to `StockCandidate`: `ieq_percentile`, `ev_percentile`, `eq_imb_percentile`, `mo_imb_percentile`, `opening_strength_score`.

#### [MODIFY] `preopen_analyzer/config.py`
- Update `GAP_BUCKETS` with the new suggested non-linear score buckets (e.g., 0-0.5% = 20-35).
- Update weighting configuration to match the 100-point scale: Gap (20), EQ Imbalance (25), IEQ (20), MO Imbalance (15), Executable Value (10), Alignment (5), Liquidity (5).

---

### Data Fetching & Hard Filters (`main.py`, `filters.py`)
#### [MODIFY] `preopen_analyzer/main.py`
- Remove the `_fetch_data` filtering that restricts to F&O + Watchlist. Instead, fetch the `ALL` category from the NSE API and process everything.
- Remove the double pipeline (`LONG` and `SHORT`). Run the pipeline once.

#### [MODIFY] `preopen_analyzer/filters.py`
- Update `apply_hard_filters` to explicitly reject:
  - `IEP <= PREV_CLOSE`
  - `IEQ <= 0`
  - `executable_value_cr < config.MIN_EXECUTABLE_VALUE_CR`

---

### Scoring Redesign (`scoring.py`)
#### [MODIFY] `preopen_analyzer/scoring.py`
- Complete rewrite of `calculate_scores`. 
- **Percentile Normalization:** Introduce cross-sectional ranking using `scipy.stats.percentileofscore` (or manual array sorting) for IEQ, Executable Value, EQ Imbalance Ratio, and MO Imbalance Ratio.
- **Base Score Calculation:** Combine the normalized features using the strict weighting.
- **Trend Modifiers:** Implement the time-series trend reward/penalties (+/- points if score/IEP/IEQ is increasing over the 30s snapshots).
- **Penalties:** Implement `StretchRisk` penalties and `OrderFlowAlignment` contradictory penalties.

---

### Output & Dashboard (`report.py`, `dashboard.py`)
#### [MODIFY] `preopen_analyzer/report.py`
- Update the CSV export header and formatting to match the EXACT 19 columns requested in the prompt (RANK, SYMBOL, OPENING_STRENGTH_SCORE, IEP, PREV_CLOSE, GAP_PCT, IEQ, EXECUTABLE_VALUE_CR, EQ_IMBALANCE, EQ_IMBALANCE_RATIO, MO_IMBALANCE, MO_IMBALANCE_RATIO, ORDER_FLOW_ALIGNMENT, LIQUIDITY_SCORE, STRETCH_RISK, 52W_STATUS, SIGNAL, REASON, WARNING).

#### [MODIFY] `dashboard.py`
- Rewrite the Streamlit UI to parse the new 19-column CSV format.
- Remove the "Shorts" table.
- Color code the new `SIGNAL` classifications (VERY STRONG, STRONG, MODERATE, WATCH, NO-GO).

## Verification Plan
1. Apply changes across all files.
2. Run `test_csv_run.py` to process historical data through the new `ALL` stocks pipeline.
3. Validate that the cross-sectional percentile normalization correctly handles 2000+ stocks.
4. Ensure the output strictly respects the 19 columns and contains no post-9:15 probabilities or entry targets.
