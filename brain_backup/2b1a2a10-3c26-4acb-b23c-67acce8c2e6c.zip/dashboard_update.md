````carousel
![Previous Dashboard — High Selling Pressure Table](file:///C:/Users/jdayalan/.gemini/antigravity/brain/2b1a2a10-3c26-4acb-b23c-67acce8c2e6c/.user_uploaded/media_1790704288674.png)
<!-- slide -->
![New Dashboard — Top 10 F&O Stocks (OI Confirmed) Table](file:///C:/Users/jdayalan/.gemini/antigravity/brain/2b1a2a10-3c26-4acb-b23c-67acce8c2e6c/.user_uploaded/media_1790693706064.png)
````
