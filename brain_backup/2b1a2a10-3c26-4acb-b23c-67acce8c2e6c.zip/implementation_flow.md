# NSE Pre-Open Market Analyzer: End-to-End Implementation Flow

This document details the exact execution pipeline of the application we built. Every 30 seconds between 9:00 AM and 9:07 AM, the system executes this precise flow.

```mermaid
flowchart TD
    A[main.py Orchestrator] -->|1. Trigger| B(nse_client.py)
    B -->|2. Raw JSON| C(normalizer.py)
    C -->|3. Normalized Snapshots| D[(data_store.py SQLite)]
    D -->|4. Current Snapshot| E(feature_engineering.py)
    D -->|5. Historical Snapshots| F(time_series.py)
    D -->|6. Historical Snapshots| G(reversal_detector.py)
    E & F & G -->|7. Feature Set| H(filters.py)
    H -->|8. Filtered Candidates| I(scoring.py)
    I -->|9. Scored Candidates| J(entry_exit.py)
    J -->|10. Final Levels| K(report.py)
    K -->|11. CSV/JSON| L[Output Files]
```

---

## 1. The Orchestrator Loop (`main.py`)
The `PreOpenAnalyzer` class manages the clock. 
* It checks the current system time. 
* If the time is before `09:00`, it sleeps.
* Between `09:00` and `09:07`, it triggers the analysis cycle exactly once every 30 seconds.
* At `09:07:01`, it breaks the loop, triggers the `_produce_final_decision()` method, prints the report, and exits.

---

## 2. Data Fetching (`nse_client.py`)
When the orchestrator triggers a cycle, the client reaches out to NSE.
* It uses the `jugaad_data` library's `NSELive` class, which handles spoofing browser headers and session cookies to bypass NSE's Akamai Web Application Firewall.
* It temporarily sets `time_out = 0` to bypass the local cache and force a fresh network request.
* It hits `https://www.nseindia.com/api/market-data-pre-open?key=FO` (or `ALL`).
* **Error Handling:** If the network fails, it implements exponential backoff (retries up to 3 times, sleeping 1s, 2s, 4s). If NSE returns an empty payload, it destroys the session, creates a new `NSELive` instance (getting fresh cookies), and tries again.

---

## 3. Data Normalization (`normalizer.py`)
The NSE API returns a massive JSON payload with inconsistent naming conventions. The normalizer fixes this.
* It maps NSE fields to our Python models (e.g., `finalQuantity` becomes `ieq`, `pChange` becomes `change_pct`).
* **Proxy Calculations:** If exact imbalance fields are missing from the NSE JSON, the normalizer computes `eq_imbalance_qty` mathematically by subtracting `total_sell_qty` from `total_buy_qty`.
* It safely casts all numbers using a `_safe_int()` helper to prevent the app from crashing if NSE sends a string like `"-"` or `null`.
* It wraps the data into a strictly typed `PreOpenSnapshot` object.

---

## 4. Persistence (`data_store.py`)
Before analyzing anything, the data is saved to a local SQLite database (`data/preopen_snapshots.db`).
* It stores the `symbol`, `timestamp`, `snapshot_number` (1 through 15), and the full JSON payload.
* **Why this matters:** To detect trends, slopes, and late reversals, the system needs to look at *past* snapshots. The database acts as the memory bank for the 9:00 to 9:07 window.

---

## 5. Basic Feature Engineering (`feature_engineering.py`)
The system takes the *current* snapshot and computes static metrics for every stock.
* **Gap Analysis:** Calculates gap percentage and groups it into buckets (`SMALL_POSITIVE`, `HEALTHY`, `EXTREME`).
* **Executable Value:** Multiplies `IEP * IEQ / 1 Crore` to find the total capital committed.
* **Demand Imbalance:** Computes the `eq_imbalance_ratio` (buyers vs sellers) and normalizes it to a [0,1] scale.
* **Stretch Risk:** Flags stocks as `LOW`, `MEDIUM`, `HIGH`, or `EXTREME` risk based on how massive the pre-market gap is.

---

## 6. Time-Series Intelligence (`time_series.py`)
The system queries the database for all previous snapshots of the current stock (e.g., snapshots 1 through 12).
* **Linear Regression:** It uses `numpy/scipy` to plot the 12 data points of the IEP (price) and calculates the mathematical slope. Is the price creeping up or bleeding down?
* **Persistence:** It calculates what percentage of the snapshots had a bullish imbalance. (e.g., "This stock had more buyers than sellers in 11 out of 12 snapshots = 91% persistence").
* **Stability:** Calculates the maximum IEP reached during the window and checks if the current IEP has drawn down from that peak.

---

## 7. Late Reversal Detection (`reversal_detector.py`)
This is a critical risk-management module. It splits the timeline of snapshots into two halves (Early vs. Late).
* It checks if the `eq_imbalance` was strongly positive in the first 3 minutes, but turned negative in the last 3 minutes.
* It checks if the IEQ (volume) was huge early on but suddenly collapsed by 9:06 AM (fake institutional orders being cancelled).
* It classifies the reversal risk as `NONE`, `LOW`, `MEDIUM`, `HIGH`, or `CRITICAL`.

---

## 8. Hard Filters & Consistency (`filters.py`)
Before scoring, stocks go through a gauntlet of hard rejection rules.
* **Rejections:** The stock is instantly marked `is_rejected = True` if: IEP is 0, IEQ is below the minimum threshold, executable value is too low, the gap is negative (we only look for LONG trades), or there is a `CRITICAL` late reversal.
* **Contradiction Detection:** Starts with a consistency score of 100. It deducts points for illogical behavior (e.g., "-15 points if the stock has a huge positive gap, but the IEP slope is actively falling").
* **Data Quality:** Deducts points if NSE failed to send data for certain snapshots for this specific stock.

---

## 9. Cross-Sectional Scoring (`scoring.py`)
This is the brain of the quantitative model. It doesn't score stocks in isolation; it scores them *against each other*.
* **Percentile Normalization:** It takes the executable value of every stock and ranks them on a scale of 0.0 to 1.0 using `scipy.stats.percentileofscore` (with Winsorization to ignore extreme outliers).
* **Base Score (0-100):** It multiplies the normalized metrics by the weights defined in `config.py` (e.g., Equilibrium Imbalance is worth 20%, IEP Stability is worth 10%).
* **Penalties:** It subtracts heavy flat penalties from the base score. (e.g., `-20 points` for a HIGH late reversal, `-15 points` for extreme stretch risk).
* The resulting `final_score` determines the signal (`STRONG_BUY` > 75, `BUY` > 55, `WATCH` > 40).

---

## 10. Entry, Exit, and Targets (`entry_exit.py`)
For the surviving top candidates, the system maps out the actual trade mechanics.
* **Aggressive Entry:** Buy immediately at the open price (IEP).
* **Conservative Entry:** Buy at a small pullback (IEP - 0.5%).
* **Targets:** Dynamically calculated based on the gap size (stocks with massive gaps get tighter targets because they are already stretched).
* **Stop Loss:** Dynamically widened if the `time_series.py` reported high volatility (standard deviation) in the IEP during the pre-open window.
* **GTT Levels:** Calculates the exact Trigger and Limit prices to feed into a broker's GTT (Good Till Triggered) API, adding a 0.03% buffer to ensure limit orders fill.

---

## 11. Final Report Generation (`report.py`)
At exactly 09:07, `main.py` halts the polling loop.
* It grabs the very last snapshot for every stock.
* It identifies the `#1 Ranked Stock` (Primary), `#2 Ranked Stock` (Secondary), and the highest scoring stock that missed a requirement (Watch).
* It formats a clean, human-readable text report for the console.
* It saves the exact Top 10 rankings to a CSV file in the `output/` folder.
* It saves a massive, detailed JSON file containing every single computed metric and reason for every stock, providing a perfect audit trail for backtesting.
