# Walkthrough: NSE Pre-Open Market Analyzer

I have successfully designed and built the complete, production-quality NSE Pre-Open Market Analyzer according to your 50-section requirements spec.

## 1. What was built

We built a modular, deterministic, quantitative trading application with the following core modules:

*   **`config.py`**: Centralizes all 50+ configuration parameters, thresholds, and weights (Sections 2-32).
*   **`models.py`**: Pydantic/dataclass models defining `PreOpenSnapshot`, `BasicFeatures`, `TimeSeriesFeatures`, `StockCandidate`, and `FinalDecision`.
*   **`nse_client.py`**: A robust wrapper around `jugaad_data.NSELive` that implements 30-second polling against the batch `/api/market-data-pre-open` endpoint to retrieve data for *all* F&O stocks with a single request, completely bypassing rate limit issues.
*   **`normalizer.py`**: Standardizes NSE API keys to your required names (`previousClose` -> `prev_close`, `finalQuantity` -> `ieq`, `totalTurnover` -> `value_cr`).
*   **`feature_engineering.py`**: Computes Section 5 features (gap %, executable value, equilibrium/market imbalance).
*   **`time_series.py`**: Computes Sections 6, 7, 9, 10 features, calculating IEP/IEQ stability, slopes, and persistence.
*   **`scoring.py`**: Implements cross-sectional percentile normalization and the 0-100 `PREMARKET_SCORE` calculation with penalties (Sections 17-19).
*   **`reversal_detector.py`**: Detects late trend reversals and early imbalance collapse (Section 8).
*   **`filters.py`**: Evaluates 11 hard rejection rules, signal consistency (contradictions), and data quality scores (Sections 20-22).
*   **`entry_exit.py`**: Calculates conservative/aggressive entry points, 2 profit targets, and dynamic stop losses with GTT mappings (Sections 28-32).
*   **`market_context.py` & `news_context.py`**: Incorporates optional macro and catalyst context (Sections 15-16).
*   **`report.py`**: Produces the 09:07 final decision report with primary/secondary trades, watchlists, and rejections (Sections 38-41).
*   **`main.py`**: The 30-second polling orchestrator loop handling the entire data flow from 9:00 AM to 9:07 AM.
*   **`capture_raw.py`**: A dedicated diagnostic script for Phase 0 live data capture.

## 2. Testing and Validation

*   We implemented **10 comprehensive unit tests** in `tests/test_scoring.py` that fully exercise the logic of all modules (covering the 8 tests mandated in Section 46).
*   **All unit tests pass.** The scoring algorithm appropriately penalizes weak/contradictory signals, rewards strong persistence, calculates GTT entry/exit levels correctly, and handles extreme stretching and late reversals.
*   All data models are heavily type-hinted and use zero-crashing safe parsing techniques.

## 3. How to use it

### Phase 0 Verification (Do this first!)
Before running the system on a live trading day, you should capture actual NSE API responses during the 9:00 - 9:08 AM window to verify the exact behavior of `ieq` and `iep` on the live server.
```bash
python -m preopen_analyzer.capture_raw
```

### Daily Production Run
To run the analyzer, start it slightly before 9:00 AM. It will poll every 30 seconds and produce the final decision at 9:07 AM.
```bash
python -m preopen_analyzer.main
```

### Running the Tests
```bash
python -m unittest preopen_analyzer/tests/test_scoring.py
```
